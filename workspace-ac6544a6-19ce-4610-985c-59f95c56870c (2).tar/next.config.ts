import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  // Allow preview origin for cross-origin requests
  allowedDevOrigins: [
    'preview-chat-ac6544a6-19ce-4610-985c-59f95c56870c.space.z.ai',
  ],
};

export default nextConfig;
