'use client';

import { useEffect, useState, useSyncExternalStore } from 'react';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { HeroSection } from '@/components/sections/HeroSection';
import { ServicesSection } from '@/components/sections/ServicesSection';
import { AboutSection } from '@/components/sections/AboutSection';
import { DoctorsSection } from '@/components/sections/DoctorsSection';
import { TestimonialsSection } from '@/components/sections/TestimonialsSection';
import { BookingSection } from '@/components/sections/BookingSection';
import { ContactSection } from '@/components/sections/ContactSection';
import { AdminPanel } from '@/components/admin/AdminPanel';
import { GoogleLoginButton } from '@/components/auth/GoogleLoginButton';
import { Service } from '@/lib/store';

// Empty snapshot for server-side rendering
const emptySnapshot = () => false;
const clientSnapshot = () => true;
const subscribe = () => () => {};

export default function Home() {
  const [preselectedService, setPreselectedService] = useState<Service | null>(null);
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  
  // Use useSyncExternalStore to detect client-side rendering
  const isClient = useSyncExternalStore(subscribe, clientSnapshot, emptySnapshot);

  useEffect(() => {
    // Seed the database on first load
    fetch('/api/seed', { method: 'POST' })
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          console.log('Database seeded successfully');
        }
      })
      .catch(console.error);
  }, []);

  const handleBookService = (service: Service) => {
    setPreselectedService(service);
    setTimeout(() => {
      document.getElementById('booking')?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  if (!isClient) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#C73E1D] via-[#8B2500] to-[#4A1200]">
        <div className="animate-pulse text-white text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        <HeroSection />
        <ServicesSection onBookService={handleBookService} />
        <AboutSection />
        <DoctorsSection />
        <TestimonialsSection />
        <BookingSection preselectedService={preselectedService} />
        <ContactSection />
      </main>
      
      <Footer />

      {/* Google Login Button - replaces the gear button */}
      <GoogleLoginButton onAdminClick={() => setShowAdminPanel(true)} />

      {/* Admin Panel */}
      <AdminPanel isOpen={showAdminPanel} onClose={() => setShowAdminPanel(false)} />
    </div>
  );
}
