import { NextResponse } from 'next/server';
import { doctorsApi } from '@/lib/google-sheets';

// GET - Fetch all doctors/staff
export async function GET() {
  try {
    const doctors = await doctorsApi.getAll();
    return NextResponse.json(doctors);
  } catch (error) {
    console.error('Error fetching doctors:', error);
    return NextResponse.json([]);
  }
}

// POST - Create new doctor/staff
export async function POST(request: Request) {
  try {
    const body = await request.json();
    
    const data = {
      name: body.name || `${body.firstName || ''} ${body.lastName || ''}`.trim(),
      email: body.email,
      phone: body.phone || '',
      specialization: body.specialization || 'General Dentist',
      photo: body.avatar || body.photo || '',
      availability: body.availability || 'Mon-Fri 9AM-5PM',
    };
    
    const result = await doctorsApi.create(data);
    
    if (result) {
      return NextResponse.json(result);
    } else {
      return NextResponse.json({ error: 'Failed to create doctor' }, { status: 500 });
    }
  } catch (error) {
    console.error('Error creating doctor:', error);
    return NextResponse.json({ error: 'Failed to create doctor' }, { status: 500 });
  }
}

// PUT - Update doctor/staff
export async function PUT(request: Request) {
  try {
    const body = await request.json();
    const { id, ...data } = body;
    
    if (!id) {
      return NextResponse.json({ error: 'ID required' }, { status: 400 });
    }
    
    // Map avatar to photo
    if (data.avatar) {
      data.photo = data.avatar;
    }
    
    const success = await doctorsApi.update(id, data);
    
    return NextResponse.json({ success });
  } catch (error) {
    console.error('Error updating doctor:', error);
    return NextResponse.json({ error: 'Failed to update doctor' }, { status: 500 });
  }
}

// DELETE - Delete doctor/staff
export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    
    if (!id) {
      return NextResponse.json({ error: 'ID required' }, { status: 400 });
    }
    
    const success = await doctorsApi.delete(id);
    return NextResponse.json({ success });
  } catch (error) {
    console.error('Error deleting doctor:', error);
    return NextResponse.json({ error: 'Failed to delete doctor' }, { status: 500 });
  }
}
