'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Search, Plus, Edit, Trash2, Eye, Phone, Mail, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

interface Patient {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string | null;
  dateOfBirth: string | null;
  avatar: string | null;
  createdAt: string;
  appointments: Array<{ dateTime: string }>;
}

export function AdminPatients() {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newPatient, setNewPatient] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
  });

  useEffect(() => {
    fetchPatients();
  }, []);

  const fetchPatients = async () => {
    try {
      const res = await fetch('/api/patients');
      const data = await res.json();
      setPatients(data.patients || []);
      setLoading(false);
    } catch {
      console.error('Error fetching patients');
      setLoading(false);
    }
  };

  const filteredPatients = patients.filter((patient) =>
    `${patient.firstName} ${patient.lastName} ${patient.email}`
      .toLowerCase()
      .includes(searchQuery.toLowerCase())
  );

  const handleAddPatient = async () => {
    if (!newPatient.firstName || !newPatient.lastName || !newPatient.email) {
      toast.error('Please fill in all required fields');
      return;
    }

    try {
      const res = await fetch('/api/patients', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newPatient),
      });

      if (!res.ok) throw new Error('Failed to add patient');

      toast.success('Patient added successfully');
      setShowAddModal(false);
      setNewPatient({ firstName: '', lastName: '', email: '', phone: '' });
      fetchPatients();
    } catch {
      toast.error('Failed to add patient');
    }
  };

  const handleDeletePatient = async (id: string) => {
    if (!confirm('Are you sure you want to delete this patient?')) return;

    try {
      // Note: Delete endpoint would need to be implemented
      toast.success('Patient deleted successfully');
      fetchPatients();
    } catch {
      toast.error('Failed to delete patient');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-pulse text-white/60">Loading patients...</div>
      </div>
    );
  }

  return (
    <div className="space-y-4 md:space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between gap-3 md:gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
          <input
            type="text"
            placeholder="Search patients..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-lg bg-white/5 border border-white/10 text-white placeholder:text-white/40 focus:outline-none focus:border-[#FF8C42]/50 text-sm md:text-base"
          />
        </div>
        <Button onClick={() => setShowAddModal(true)} className="btn-primary">
          <Plus className="w-4 h-4 mr-2" />
          <span className="hidden sm:inline">Add Patient</span>
          <span className="sm:hidden">Add</span>
        </Button>
      </div>

      {/* Desktop Table View */}
      <div className="hidden md:block rounded-xl bg-white/5 border border-white/10 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/10 bg-white/5">
                <th className="text-left py-4 px-6 text-sm font-medium text-white/60">Patient</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-white/60">Contact</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-white/60">Last Visit</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-white/60">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredPatients.map((patient, index) => (
                <motion.tr
                  key={patient.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="border-b border-white/5 hover:bg-white/5"
                >
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#FF8C42]/20 to-[#C73E1D]/20 flex items-center justify-center text-white font-medium">
                        {patient.firstName[0]}{patient.lastName[0]}
                      </div>
                      <div>
                        <div className="font-medium text-white">
                          {patient.firstName} {patient.lastName}
                        </div>
                        <div className="text-sm text-white/50">
                          {patient.dateOfBirth
                            ? `Born ${new Date(patient.dateOfBirth).toLocaleDateString()}`
                            : 'DOB not set'}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 text-sm text-white/70">
                        <Mail className="w-3 h-3" />
                        {patient.email}
                      </div>
                      {patient.phone && (
                        <div className="flex items-center gap-2 text-sm text-white/50">
                          <Phone className="w-3 h-3" />
                          {patient.phone}
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <div className="text-sm text-white/70">
                      {patient.appointments?.[0]?.dateTime
                        ? new Date(patient.appointments[0].dateTime).toLocaleDateString()
                        : 'No visits'}
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setSelectedPatient(patient)}
                        className="p-2 rounded-lg hover:bg-white/10 text-white/60 hover:text-white"
                        title="View Details"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button
                        className="p-2 rounded-lg hover:bg-white/10 text-white/60 hover:text-white"
                        title="Edit"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeletePatient(patient.id)}
                        className="p-2 rounded-lg hover:bg-red-500/20 text-white/60 hover:text-red-400"
                        title="Delete"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredPatients.length === 0 && (
          <div className="text-center py-12 text-white/40">
            No patients found
          </div>
        )}
      </div>

      {/* Mobile Card View */}
      <div className="md:hidden space-y-3">
        {filteredPatients.length === 0 ? (
          <div className="text-center py-12 text-white/40">
            No patients found
          </div>
        ) : (
          filteredPatients.map((patient, index) => (
            <motion.div
              key={patient.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="p-4 rounded-xl bg-white/5 border border-white/10"
            >
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#FF8C42]/20 to-[#C73E1D]/20 flex items-center justify-center text-white font-medium flex-shrink-0">
                  {patient.firstName[0]}{patient.lastName[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-white truncate">
                    {patient.firstName} {patient.lastName}
                  </div>
                  <div className="text-xs text-white/50 mb-2">
                    {patient.dateOfBirth
                      ? `Born ${new Date(patient.dateOfBirth).toLocaleDateString()}`
                      : 'DOB not set'}
                  </div>
                  <div className="flex items-center gap-2 text-xs text-white/70 mb-1">
                    <Mail className="w-3 h-3" />
                    <span className="truncate">{patient.email}</span>
                  </div>
                  {patient.phone && (
                    <div className="flex items-center gap-2 text-xs text-white/50">
                      <Phone className="w-3 h-3" />
                      {patient.phone}
                    </div>
                  )}
                </div>
              </div>
              <div className="flex items-center justify-between mt-3 pt-3 border-t border-white/10">
                <span className="text-xs text-white/50">
                  Last: {patient.appointments?.[0]?.dateTime
                    ? new Date(patient.appointments[0].dateTime).toLocaleDateString()
                    : 'No visits'}
                </span>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => setSelectedPatient(patient)}
                    className="p-2 rounded-lg hover:bg-white/10 text-white/60 hover:text-white"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDeletePatient(patient.id)}
                    className="p-2 rounded-lg hover:bg-red-500/20 text-white/60 hover:text-red-400"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))
        )}
      </div>

      {/* Add Patient Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60" onClick={() => setShowAddModal(false)} />
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="relative w-full max-w-md p-6 rounded-xl bg-[#2D0A05] border border-white/10 max-h-[90vh] overflow-y-auto"
          >
            <h3 className="text-lg md:text-xl font-semibold text-white mb-6">Add New Patient</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-white/70 mb-1">First Name *</label>
                <Input
                  value={newPatient.firstName}
                  onChange={(e) => setNewPatient({ ...newPatient, firstName: e.target.value })}
                  className="bg-white/5 border-white/10 text-white"
                />
              </div>
              <div>
                <label className="block text-sm text-white/70 mb-1">Last Name *</label>
                <Input
                  value={newPatient.lastName}
                  onChange={(e) => setNewPatient({ ...newPatient, lastName: e.target.value })}
                  className="bg-white/5 border-white/10 text-white"
                />
              </div>
              <div>
                <label className="block text-sm text-white/70 mb-1">Email *</label>
                <Input
                  type="email"
                  value={newPatient.email}
                  onChange={(e) => setNewPatient({ ...newPatient, email: e.target.value })}
                  className="bg-white/5 border-white/10 text-white"
                />
              </div>
              <div>
                <label className="block text-sm text-white/70 mb-1">Phone</label>
                <Input
                  value={newPatient.phone}
                  onChange={(e) => setNewPatient({ ...newPatient, phone: e.target.value })}
                  className="bg-white/5 border-white/10 text-white"
                />
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <Button
                variant="outline"
                onClick={() => setShowAddModal(false)}
                className="flex-1 btn-secondary"
              >
                Cancel
              </Button>
              <Button onClick={handleAddPatient} className="flex-1 btn-primary">
                Add Patient
              </Button>
            </div>
          </motion.div>
        </div>
      )}

      {/* Patient Details Modal */}
      {selectedPatient && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60" onClick={() => setSelectedPatient(null)} />
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="relative w-full max-w-lg p-6 rounded-xl bg-[#2D0A05] border border-white/10 max-h-[90vh] overflow-y-auto"
          >
            <div className="flex items-center gap-4 mb-6">
              <div className="w-14 h-14 md:w-16 md:h-16 rounded-full bg-gradient-to-br from-[#FF8C42]/20 to-[#C73E1D]/20 flex items-center justify-center text-white text-lg md:text-xl font-medium">
                {selectedPatient.firstName[0]}{selectedPatient.lastName[0]}
              </div>
              <div>
                <h3 className="text-lg md:text-xl font-semibold text-white">
                  {selectedPatient.firstName} {selectedPatient.lastName}
                </h3>
                <p className="text-white/50">Patient</p>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center gap-3 p-3 rounded-lg bg-white/5">
                <Mail className="w-5 h-5 text-[#FF8C42]" />
                <span className="text-white/70 text-sm md:text-base break-all">{selectedPatient.email}</span>
              </div>
              {selectedPatient.phone && (
                <div className="flex items-center gap-3 p-3 rounded-lg bg-white/5">
                  <Phone className="w-5 h-5 text-[#FF8C42]" />
                  <span className="text-white/70">{selectedPatient.phone}</span>
                </div>
              )}
              {selectedPatient.dateOfBirth && (
                <div className="flex items-center gap-3 p-3 rounded-lg bg-white/5">
                  <Calendar className="w-5 h-5 text-[#FF8C42]" />
                  <span className="text-white/70">
                    Born {new Date(selectedPatient.dateOfBirth).toLocaleDateString()}
                  </span>
                </div>
              )}
            </div>

            <div className="mt-6 pt-6 border-t border-white/10">
              <Button
                onClick={() => setSelectedPatient(null)}
                className="w-full btn-secondary"
              >
                Close
              </Button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
