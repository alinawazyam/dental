'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Plus, Edit, Trash2, ToggleLeft, ToggleRight, Clock, DollarSign } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { useSettings } from '@/lib/settings-store';

interface Service {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  shortDescription: string | null;
  duration: number;
  price: number;
  category: string;
  image: string | null;
  isActive: boolean;
  featured: boolean;
}

const categories = [
  'IMPLANTS',
  'COSMETIC',
  'PREVENTIVE',
  'ORTHODONTICS',
  'SURGERY',
  'RESTORATIVE',
];

const serviceIcons: Record<string, string> = {
  IMPLANTS: '🦷',
  COSMETIC: '✨',
  PREVENTIVE: '🪥',
  ORTHODONTICS: '😁',
  SURGERY: '⚕️',
  RESTORATIVE: '🔧',
};

export function AdminServices() {
  const [services, setServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingService, setEditingService] = useState<Service | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    shortDescription: '',
    duration: 60,
    price: 0,
    category: 'PREVENTIVE',
    featured: false,
  });
  const { settings } = useSettings();

  const formatCurrency = (amount: number) => {
    return `${settings.currencySymbol}${amount.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
  };

  useEffect(() => {
    fetchServices();
  }, []);

  const fetchServices = async () => {
    try {
      const res = await fetch('/api/services');
      const data = await res.json();
      setServices(data);
      setLoading(false);
    } catch {
      console.error('Error fetching services');
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    if (!formData.name || !formData.price) {
      toast.error('Please fill in all required fields');
      return;
    }

    try {
      const res = await fetch('/api/services', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          slug: formData.name.toLowerCase().replace(/\s+/g, '-'),
        }),
      });

      if (!res.ok) throw new Error('Failed to add service');

      toast.success('Service added successfully');
      setShowAddModal(false);
      resetForm();
      fetchServices();
    } catch {
      toast.error('Failed to add service');
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      shortDescription: '',
      duration: 60,
      price: 0,
      category: 'PREVENTIVE',
      featured: false,
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-pulse text-white/60">Loading services...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-lg text-white/70">{services.length} services</h2>
        </div>
        <Button onClick={() => setShowAddModal(true)} className="btn-primary">
          <Plus className="w-4 h-4 mr-2" />
          Add Service
        </Button>
      </div>

      {/* Services Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {services.map((service, index) => (
          <motion.div
            key={service.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className={`p-6 rounded-xl border ${
              service.isActive
                ? 'bg-white/5 border-white/10'
                : 'bg-white/2 border-white/5 opacity-60'
            }`}
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#FF8C42]/20 to-[#C73E1D]/20 flex items-center justify-center text-2xl">
                  {serviceIcons[service.category] || '🦷'}
                </div>
                <div>
                  <h3 className="font-semibold text-white">{service.name}</h3>
                  <span className="text-xs text-white/50">{service.category}</span>
                </div>
              </div>
              {service.featured && (
                <span className="px-2 py-1 rounded-full bg-[#FF8C42]/20 text-[#FF8C42] text-xs">
                  Featured
                </span>
              )}
            </div>

            <p className="text-sm text-white/60 mb-4 line-clamp-2">
              {service.shortDescription || service.description}
            </p>

            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-4 text-sm text-white/60">
                <span className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  {service.duration} min
                </span>
                <span className="flex items-center gap-1">
                  <DollarSign className="w-4 h-4" />
                  {formatCurrency(service.price)}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-white/10">
              <div className="flex items-center gap-2">
                {service.isActive ? (
                  <ToggleRight className="w-5 h-5 text-green-400" />
                ) : (
                  <ToggleLeft className="w-5 h-5 text-white/40" />
                )}
                <span className={`text-sm ${service.isActive ? 'text-green-400' : 'text-white/40'}`}>
                  {service.isActive ? 'Active' : 'Inactive'}
                </span>
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => setEditingService(service)}
                  className="p-2 rounded-lg hover:bg-white/10 text-white/60 hover:text-white"
                >
                  <Edit className="w-4 h-4" />
                </button>
                <button
                  className="p-2 rounded-lg hover:bg-red-500/20 text-white/60 hover:text-red-400"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Add/Edit Modal */}
      {(showAddModal || editingService) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-black/60"
            onClick={() => {
              setShowAddModal(false);
              setEditingService(null);
              resetForm();
            }}
          />
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="relative w-full max-w-lg p-6 rounded-xl bg-[#2D0A05] border border-white/10 max-h-[90vh] overflow-y-auto"
          >
            <h3 className="text-xl font-semibold text-white mb-6">
              {editingService ? 'Edit Service' : 'Add New Service'}
            </h3>

            <div className="space-y-4">
              <div>
                <label className="block text-sm text-white/70 mb-1">Service Name *</label>
                <Input
                  value={editingService ? editingService.name : formData.name}
                  onChange={(e) =>
                    editingService
                      ? setEditingService({ ...editingService, name: e.target.value })
                      : setFormData({ ...formData, name: e.target.value })
                  }
                  className="bg-white/5 border-white/10 text-white"
                />
              </div>

              <div>
                <label className="block text-sm text-white/70 mb-1">Short Description</label>
                <Input
                  value={editingService ? editingService.shortDescription || '' : formData.shortDescription}
                  onChange={(e) =>
                    editingService
                      ? setEditingService({ ...editingService, shortDescription: e.target.value })
                      : setFormData({ ...formData, shortDescription: e.target.value })
                  }
                  className="bg-white/5 border-white/10 text-white"
                />
              </div>

              <div>
                <label className="block text-sm text-white/70 mb-1">Full Description</label>
                <Textarea
                  value={editingService ? editingService.description || '' : formData.description}
                  onChange={(e) =>
                    editingService
                      ? setEditingService({ ...editingService, description: e.target.value })
                      : setFormData({ ...formData, description: e.target.value })
                  }
                  className="bg-white/5 border-white/10 text-white resize-none"
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-white/70 mb-1">Duration (min) *</label>
                  <Input
                    type="number"
                    value={editingService ? editingService.duration : formData.duration}
                    onChange={(e) =>
                      editingService
                        ? setEditingService({ ...editingService, duration: parseInt(e.target.value) })
                        : setFormData({ ...formData, duration: parseInt(e.target.value) })
                    }
                    className="bg-white/5 border-white/10 text-white"
                  />
                </div>
                <div>
                  <label className="block text-sm text-white/70 mb-1">Price ({settings.currencySymbol}) *</label>
                  <Input
                    type="number"
                    value={editingService ? editingService.price : formData.price}
                    onChange={(e) =>
                      editingService
                        ? setEditingService({ ...editingService, price: parseFloat(e.target.value) })
                        : setFormData({ ...formData, price: parseFloat(e.target.value) })
                    }
                    className="bg-white/5 border-white/10 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm text-white/70 mb-1">Category</label>
                <select
                  value={editingService ? editingService.category : formData.category}
                  onChange={(e) =>
                    editingService
                      ? setEditingService({ ...editingService, category: e.target.value })
                      : setFormData({ ...formData, category: e.target.value })
                  }
                  className="w-full px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#FF8C42]/50"
                >
                  {categories.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="featured"
                  checked={editingService ? editingService.featured : formData.featured}
                  onChange={(e) =>
                    editingService
                      ? setEditingService({ ...editingService, featured: e.target.checked })
                      : setFormData({ ...formData, featured: e.target.checked })
                  }
                  className="w-4 h-4 rounded border-white/20 bg-white/5"
                />
                <label htmlFor="featured" className="text-sm text-white/70">
                  Feature this service
                </label>
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <Button
                variant="outline"
                onClick={() => {
                  setShowAddModal(false);
                  setEditingService(null);
                  resetForm();
                }}
                className="flex-1 btn-secondary"
              >
                Cancel
              </Button>
              <Button onClick={handleSubmit} className="flex-1 btn-primary">
                {editingService ? 'Save Changes' : 'Add Service'}
              </Button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
