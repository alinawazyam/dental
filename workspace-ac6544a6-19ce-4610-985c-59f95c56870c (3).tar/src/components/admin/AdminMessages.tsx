'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, Clock, CheckCircle, Trash2, Loader2, MessageSquare, User, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

interface Message {
  id: string;
  name: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
  status: string;
  createdAt: string;
}

export function AdminMessages() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedMessage, setSelectedMessage] = useState<Message | null>(null);

  useEffect(() => {
    const fetchMessages = async () => {
      try {
        const res = await fetch('/api/messages');
        const data = await res.json();
        setMessages(Array.isArray(data) ? data : []);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching messages:', error);
        setLoading(false);
      }
    };
    
    fetchMessages();
  }, []);

  const handleMarkAsRead = async (id: string) => {
    try {
      const res = await fetch('/api/messages', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status: 'read' }),
      });

      const data = await res.json();
      if (data.success) {
        setMessages(prev => 
          prev.map(m => m.id === id ? { ...m, status: 'read' } : m)
        );
        toast.success('Message marked as read');
      }
    } catch (error) {
      console.error('Error updating message:', error);
      toast.error('Failed to update message');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this message?')) return;

    try {
      const res = await fetch(`/api/messages?id=${id}`, { method: 'DELETE' });
      const data = await res.json();
      
      if (data.success) {
        setMessages(prev => prev.filter(m => m.id !== id));
        setSelectedMessage(null);
        toast.success('Message deleted');
      }
    } catch (error) {
      console.error('Error deleting message:', error);
      toast.error('Failed to delete message');
    }
  };

  const unreadCount = messages.filter(m => m.status === 'unread').length;

  const formatDate = (dateStr: string) => {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 text-[#FF8C42] animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-4 md:space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl md:text-2xl font-semibold text-white">Messages</h2>
          <p className="text-sm md:text-base text-white/60">
            {unreadCount > 0 ? `${unreadCount} unread messages` : `${messages.length} total messages`}
          </p>
        </div>
      </div>

      {messages.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-64 text-white/40">
          <MessageSquare className="w-12 h-12 md:w-16 md:h-16 mb-4" />
          <p>No messages yet</p>
        </div>
      ) : (
        <div className="grid lg:grid-cols-3 gap-4 md:gap-6">
          {/* Messages List */}
          <div className={`lg:col-span-1 space-y-2 max-h-[calc(100vh-250px)] overflow-y-auto pr-0 md:pr-2 ${selectedMessage ? 'hidden lg:block' : ''}`}>
            {messages.map((message, index) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                onClick={() => {
                  setSelectedMessage(message);
                  if (message.status === 'unread') {
                    handleMarkAsRead(message.id);
                  }
                }}
                className={`p-3 md:p-4 rounded-xl cursor-pointer transition-all ${
                  selectedMessage?.id === message.id
                    ? 'bg-[#C73E1D]/20 border border-[#C73E1D]/50'
                    : message.status === 'unread'
                    ? 'bg-white/10 border border-white/20 hover:bg-white/15'
                    : 'bg-white/5 border border-white/10 hover:bg-white/10'
                }`}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    {message.status === 'unread' && (
                      <span className="w-2 h-2 bg-[#FF8C42] rounded-full flex-shrink-0" />
                    )}
                    <h4 className="font-medium text-white truncate text-sm md:text-base">{message.name}</h4>
                  </div>
                  <span className="text-xs text-white/40 flex-shrink-0 ml-2">{formatDate(message.createdAt)}</span>
                </div>
                <p className="text-xs md:text-sm text-white/70 truncate mb-1">{message.subject}</p>
                <p className="text-xs text-white/50 truncate">{message.message}</p>
              </motion.div>
            ))}
          </div>

          {/* Message Detail */}
          <div className={`lg:col-span-2 ${!selectedMessage ? 'hidden lg:block' : ''}`}>
            {selectedMessage ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="p-4 md:p-6 rounded-xl bg-white/5 border border-white/10"
              >
                {/* Mobile back button */}
                <button
                  onClick={() => setSelectedMessage(null)}
                  className="lg:hidden flex items-center gap-2 text-white/60 hover:text-white mb-4"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Back to messages
                </button>

                <div className="flex flex-col sm:flex-row items-start justify-between gap-4 mb-6">
                  <div className="flex items-center gap-3 md:gap-4">
                    <div className="w-12 h-12 md:w-14 md:h-14 rounded-full bg-gradient-to-br from-[#FF8C42]/20 to-[#C73E1D]/20 flex items-center justify-center flex-shrink-0">
                      <User className="w-5 h-5 md:w-6 md:h-6 text-[#FF8C42]" />
                    </div>
                    <div className="min-w-0">
                      <h3 className="text-lg md:text-xl font-semibold text-white">{selectedMessage.name}</h3>
                      <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-4 text-xs md:text-sm text-white/60 mt-1">
                        <span className="flex items-center gap-1 truncate">
                          <Mail className="w-3 h-3 md:w-4 md:h-4 flex-shrink-0" />
                          <span className="truncate">{selectedMessage.email}</span>
                        </span>
                        {selectedMessage.phone && (
                          <span className="flex items-center gap-1">
                            <Phone className="w-3 h-3 md:w-4 md:h-4 flex-shrink-0" />
                            {selectedMessage.phone}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  <Button
                    onClick={() => handleDelete(selectedMessage.id)}
                    variant="outline"
                    className="text-red-400 border-red-400/30 hover:bg-red-400/10 text-sm"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Delete
                  </Button>
                </div>

                <div className="space-y-4">
                  <div className="flex flex-wrap items-center gap-2 text-white/60">
                    <Clock className="w-4 h-4" />
                    <span className="text-xs md:text-sm">{formatDate(selectedMessage.createdAt)}</span>
                    <span className={`px-2 py-0.5 rounded-full text-xs ${
                      selectedMessage.status === 'unread' 
                        ? 'bg-[#FF8C42]/20 text-[#FF8C42]' 
                        : 'bg-green-500/20 text-green-400'
                    }`}>
                      {selectedMessage.status === 'unread' ? 'Unread' : 'Read'}
                    </span>
                  </div>

                  <div>
                    <h4 className="text-base md:text-lg font-medium text-white mb-2">{selectedMessage.subject}</h4>
                    <div className="p-3 md:p-4 rounded-lg bg-white/5 border border-white/10">
                      <p className="text-white/80 whitespace-pre-wrap text-sm md:text-base">{selectedMessage.message}</p>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-3 pt-4">
                    <a
                      href={`mailto:${selectedMessage.email}?subject=${encodeURIComponent(`Re: ${selectedMessage.subject}`)}&body=${encodeURIComponent(`\n\n--- Original Message ---\nFrom: ${selectedMessage.name}\nDate: ${formatDate(selectedMessage.createdAt)}\n\n${selectedMessage.message}`)}`}
                      className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-gradient-to-r from-[#FF8C42] to-[#C73E1D] text-white font-medium hover:opacity-90 transition-opacity"
                    >
                      <Mail className="w-4 h-4" />
                      Reply via Email
                    </a>
                    {selectedMessage.phone && (
                      <a
                        href={`tel:${selectedMessage.phone}`}
                        className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-lg border border-white/20 text-white/70 hover:bg-white/10 transition-colors"
                      >
                        <Phone className="w-4 h-4" />
                        Call
                      </a>
                    )}
                  </div>
                </div>
              </motion.div>
            ) : (
              <div className="flex flex-col items-center justify-center h-64 text-white/40">
                <MessageSquare className="w-12 h-12 md:w-16 md:h-16 mb-4" />
                <p className="text-sm md:text-base">Select a message to view details</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
