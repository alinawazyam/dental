'use client';

import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  DollarSign,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  CreditCard,
  Download,
  Eye,
  Filter,
  Plus,
  Printer,
  Send,
  Wallet,
  Building2,
  Banknote,
  Smartphone,
  Receipt,
  X,
  Loader2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { useSettings } from '@/lib/settings-store';

interface Invoice {
  id: string;
  invoiceNumber: string;
  amount: number;
  tax: number;
  discount: number;
  total: number;
  status: string;
  paidAt: string | null;
  dueDate: string | null;
  notes: string | null;
  createdAt: string;
  patient: {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
    phone?: string;
    address?: string;
  };
  appointment?: {
    service?: {
      name: string;
      price: number;
    };
    doctor?: {
      firstName: string;
      lastName: string;
    };
  };
}

interface Patient {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
}

const statusConfig: Record<string, { color: string; bg: string; icon: typeof CheckCircle }> = {
  PENDING: { color: 'text-yellow-400', bg: 'bg-yellow-500/20', icon: Clock },
  PAID: { color: 'text-green-400', bg: 'bg-green-500/20', icon: CheckCircle },
  OVERDUE: { color: 'text-red-400', bg: 'bg-red-500/20', icon: AlertCircle },
  CANCELLED: { color: 'text-white/40', bg: 'bg-white/10', icon: XCircle },
  REFUNDED: { color: 'text-purple-400', bg: 'bg-purple-500/20', icon: DollarSign },
};

const paymentMethods = [
  { id: 'cash', name: 'Cash', icon: Banknote, color: 'text-green-400' },
  { id: 'card', name: 'Card', icon: CreditCard, color: 'text-blue-400' },
  { id: 'bank', name: 'Bank', icon: Building2, color: 'text-purple-400' },
  { id: 'paypal', name: 'PayPal', icon: Wallet, color: 'text-yellow-400' },
  { id: 'stripe', name: 'Stripe', icon: CreditCard, color: 'text-indigo-400' },
  { id: 'upi', name: 'UPI', icon: Smartphone, color: 'text-orange-400' },
];

export function AdminBilling() {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [showCreateInvoice, setShowCreateInvoice] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [processingPayment, setProcessingPayment] = useState(false);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<string>('cash');
  const [stats, setStats] = useState({
    total: 0,
    paid: 0,
    pending: 0,
    overdue: 0,
    totalRevenue: 0,
  });
  const invoicesRef = useRef<Invoice[]>([]);

  const [newInvoice, setNewInvoice] = useState({
    patientId: '',
    amount: '',
    tax: '0',
    discount: '0',
    notes: '',
    dueDate: '',
  });

  // Load invoices on mount
  useEffect(() => {
    const controller = new AbortController();

    const loadData = async () => {
      try {
        const [invoicesRes, patientsRes] = await Promise.all([
          fetch('/api/invoices', { signal: controller.signal }),
          fetch('/api/patients', { signal: controller.signal }),
        ]);
        const invoicesData = await invoicesRes.json();
        const patientsData = await patientsRes.json();

        // Ensure we have arrays
        const invoicesArray = Array.isArray(invoicesData) ? invoicesData : [];
        const patientsArray = Array.isArray(patientsData) ? patientsData : [];

        invoicesRef.current = invoicesArray;
        setInvoices(invoicesArray);
        setPatients(patientsArray);

        // Calculate stats
        const total = invoicesArray.length;
        const paid = invoicesArray.filter((inv: Invoice) => inv.status === 'PAID').length;
        const pending = invoicesArray.filter((inv: Invoice) => inv.status === 'PENDING').length;
        const overdue = invoicesArray.filter((inv: Invoice) => inv.status === 'OVERDUE').length;
        const totalRevenue = invoicesArray
          .filter((inv: Invoice) => inv.status === 'PAID')
          .reduce((sum: number, inv: Invoice) => sum + inv.total, 0);

        setStats({ total, paid, pending, overdue, totalRevenue });
        setLoading(false);
      } catch {
        if (!controller.signal.aborted) {
          setLoading(false);
        }
      }
    };

    loadData();

    return () => controller.abort();
  }, []);

  const refreshInvoices = async () => {
    try {
      const res = await fetch('/api/invoices');
      const data = await res.json();
      
      // Ensure we have an array
      const invoicesArray = Array.isArray(data) ? data : [];
      
      invoicesRef.current = invoicesArray;
      setInvoices(invoicesArray);

      const total = invoicesArray.length;
      const paid = invoicesArray.filter((inv: Invoice) => inv.status === 'PAID').length;
      const pending = invoicesArray.filter((inv: Invoice) => inv.status === 'PENDING').length;
      const overdue = invoicesArray.filter((inv: Invoice) => inv.status === 'OVERDUE').length;
      const totalRevenue = invoicesArray
        .filter((inv: Invoice) => inv.status === 'PAID')
        .reduce((sum: number, inv: Invoice) => sum + inv.total, 0);

      setStats({ total, paid, pending, overdue, totalRevenue });
    } catch {
      console.error('Error refreshing invoices');
    }
  };

  const handleCreateInvoice = async () => {
    if (!newInvoice.patientId || !newInvoice.amount) {
      toast.error('Please fill in all required fields');
      return;
    }

    try {
      const amount = parseFloat(newInvoice.amount);
      const tax = parseFloat(newInvoice.tax) || 0;
      const discount = parseFloat(newInvoice.discount) || 0;
      const total = amount + (amount * tax / 100) - discount;

      const res = await fetch('/api/invoices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          patientId: newInvoice.patientId,
          amount,
          tax,
          discount,
          total,
          notes: newInvoice.notes,
          dueDate: newInvoice.dueDate || null,
        }),
      });

      if (!res.ok) throw new Error('Failed to create invoice');

      toast.success('Invoice created successfully!');
      setShowCreateInvoice(false);
      setNewInvoice({
        patientId: '',
        amount: '',
        tax: '0',
        discount: '0',
        notes: '',
        dueDate: '',
      });
      refreshInvoices();
    } catch {
      toast.error('Failed to create invoice');
    }
  };

  const handlePayment = async () => {
    if (!selectedInvoice) return;

    setProcessingPayment(true);

    // Simulate payment processing
    await new Promise((resolve) => setTimeout(resolve, 1500));

    try {
      const res = await fetch('/api/invoices', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: selectedInvoice.id,
          status: 'PAID',
          paymentMethod: selectedPaymentMethod,
          paidAt: new Date().toISOString(),
        }),
      });

      if (!res.ok) throw new Error('Failed to process payment');

      toast.success('Payment processed successfully!');
      setShowPaymentModal(false);
      setSelectedInvoice(null);
      refreshInvoices();
    } catch {
      toast.error('Failed to process payment');
    } finally {
      setProcessingPayment(false);
    }
  };

  const handleStatusChange = async (invoiceId: string, newStatus: string) => {
    try {
      await fetch('/api/invoices', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: invoiceId, status: newStatus }),
      });
      refreshInvoices();
      toast.success('Invoice status updated');
    } catch {
      console.error('Error updating invoice');
    }
  };

  const filteredInvoices = filterStatus === 'all'
    ? invoices
    : invoices.filter((inv) => inv.status === filterStatus);

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  // Use settings for currency
  const { settings } = useSettings();
  
  const formatCurrency = (amount: number) => {
    return `${settings.currencySymbol}${amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-pulse text-white/60">Loading invoices...</div>
      </div>
    );
  }

  return (
    <div className="space-y-4 md:space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2 md:gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-3 md:p-4 rounded-xl bg-white/5 border border-white/10"
        >
          <div className="flex items-center gap-2 text-white/60 mb-1">
            <Receipt className="w-3 h-3 md:w-4 md:h-4" />
            <span className="text-xs md:text-sm">Total</span>
          </div>
          <div className="text-lg md:text-2xl font-bold text-white">{stats.total}</div>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
          className="p-3 md:p-4 rounded-xl bg-green-500/10 border border-green-500/20"
        >
          <div className="flex items-center gap-2 text-green-400/60 mb-1">
            <CheckCircle className="w-3 h-3 md:w-4 md:h-4" />
            <span className="text-xs md:text-sm">Paid</span>
          </div>
          <div className="text-lg md:text-2xl font-bold text-green-400">{stats.paid}</div>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="p-3 md:p-4 rounded-xl bg-yellow-500/10 border border-yellow-500/20"
        >
          <div className="flex items-center gap-2 text-yellow-400/60 mb-1">
            <Clock className="w-3 h-3 md:w-4 md:h-4" />
            <span className="text-xs md:text-sm">Pending</span>
          </div>
          <div className="text-lg md:text-2xl font-bold text-yellow-400">{stats.pending}</div>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="p-3 md:p-4 rounded-xl bg-red-500/10 border border-red-500/20"
        >
          <div className="flex items-center gap-2 text-red-400/60 mb-1">
            <AlertCircle className="w-3 h-3 md:w-4 md:h-4" />
            <span className="text-xs md:text-sm">Overdue</span>
          </div>
          <div className="text-lg md:text-2xl font-bold text-red-400">{stats.overdue}</div>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="col-span-2 sm:col-span-1 p-3 md:p-4 rounded-xl bg-[#FF8C42]/10 border border-[#FF8C42]/20"
        >
          <div className="flex items-center gap-2 text-[#FF8C42]/60 mb-1">
            <DollarSign className="w-3 h-3 md:w-4 md:h-4" />
            <span className="text-xs md:text-sm">Revenue</span>
          </div>
          <div className="text-lg md:text-2xl font-bold text-[#FF8C42]">{formatCurrency(stats.totalRevenue)}</div>
        </motion.div>
      </div>

      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between gap-3 md:gap-4">
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-white/60" />
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#FF8C42]/50 text-sm"
          >
            <option value="all">All Status</option>
            <option value="PENDING">Pending</option>
            <option value="PAID">Paid</option>
            <option value="OVERDUE">Overdue</option>
            <option value="CANCELLED">Cancelled</option>
          </select>
        </div>
        <Button onClick={() => setShowCreateInvoice(true)} className="btn-primary">
          <Plus className="w-4 h-4 mr-2" />
          <span className="hidden sm:inline">Create Invoice</span>
          <span className="sm:hidden">Invoice</span>
        </Button>
      </div>

      {/* Desktop Table View */}
      <div className="hidden md:block rounded-xl bg-white/5 border border-white/10 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/10 bg-white/5">
                <th className="text-left py-4 px-6 text-sm font-medium text-white/60">Invoice</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-white/60">Patient</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-white/60">Service</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-white/60">Amount</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-white/60">Status</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-white/60">Date</th>
                <th className="text-left py-4 px-6 text-sm font-medium text-white/60">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredInvoices.map((invoice, index) => {
                const StatusIcon = statusConfig[invoice.status]?.icon || Clock;
                const statusStyle = statusConfig[invoice.status] || statusConfig.PENDING;

                return (
                  <motion.tr
                    key={invoice.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.03 }}
                    className="border-b border-white/5 hover:bg-white/5"
                  >
                    <td className="py-4 px-6">
                      <div className="font-mono text-white">{invoice.invoiceNumber}</div>
                    </td>
                    <td className="py-4 px-6">
                      <div className="text-white">{invoice.patient?.firstName} {invoice.patient?.lastName}</div>
                      <div className="text-sm text-white/50">{invoice.patient?.email}</div>
                    </td>
                    <td className="py-4 px-6 text-white/70">
                      {invoice.appointment?.service?.name || 'N/A'}
                    </td>
                    <td className="py-4 px-6">
                      <div className="text-white font-medium">{formatCurrency(invoice.total)}</div>
                      {invoice.discount > 0 && (
                        <div className="text-xs text-green-400">-{formatCurrency(invoice.discount)} discount</div>
                      )}
                    </td>
                    <td className="py-4 px-6">
                      <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-sm ${statusStyle.bg} ${statusStyle.color}`}>
                        <StatusIcon className="w-3.5 h-3.5" />
                        {invoice.status}
                      </div>
                    </td>
                    <td className="py-4 px-6 text-white/60 text-sm">
                      {formatDate(invoice.createdAt)}
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => setSelectedInvoice(invoice)}
                          className="p-2 rounded-lg hover:bg-white/10 text-white/60 hover:text-white"
                          title="View"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        {invoice.status === 'PENDING' && (
                          <button
                            onClick={() => {
                              setSelectedInvoice(invoice);
                              setShowPaymentModal(true);
                            }}
                            className="p-2 rounded-lg hover:bg-green-500/20 text-green-400"
                            title="Accept Payment"
                          >
                            <CreditCard className="w-4 h-4" />
                          </button>
                        )}
                        <select
                          value={invoice.status}
                          onChange={(e) => handleStatusChange(invoice.id, e.target.value)}
                          className="px-2 py-1 rounded-lg bg-white/5 border border-white/10 text-xs text-white/70 focus:outline-none"
                        >
                          <option value="PENDING">Pending</option>
                          <option value="PAID">Paid</option>
                          <option value="OVERDUE">Overdue</option>
                          <option value="CANCELLED">Cancelled</option>
                          <option value="REFUNDED">Refunded</option>
                        </select>
                      </div>
                    </td>
                  </motion.tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {filteredInvoices.length === 0 && (
          <div className="text-center py-12 text-white/40">
            No invoices found
          </div>
        )}
      </div>

      {/* Mobile Card View */}
      <div className="md:hidden space-y-3">
        {filteredInvoices.length === 0 ? (
          <div className="text-center py-12 text-white/40">
            No invoices found
          </div>
        ) : (
          filteredInvoices.map((invoice, index) => {
            const StatusIcon = statusConfig[invoice.status]?.icon || Clock;
            const statusStyle = statusConfig[invoice.status] || statusConfig.PENDING;

            return (
              <motion.div
                key={invoice.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.03 }}
                className="p-4 rounded-xl bg-white/5 border border-white/10"
              >
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="font-mono text-white font-medium">{invoice.invoiceNumber}</div>
                    <div className="text-sm text-white/50">{formatDate(invoice.createdAt)}</div>
                  </div>
                  <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs ${statusStyle.bg} ${statusStyle.color}`}>
                    <StatusIcon className="w-3 h-3" />
                    {invoice.status}
                  </div>
                </div>
                
                <div className="mb-3">
                  <div className="text-white">{invoice.patient?.firstName} {invoice.patient?.lastName}</div>
                  <div className="text-xs text-white/50">{invoice.patient?.email}</div>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-white/10">
                  <div className="text-lg font-bold text-[#FF8C42]">{formatCurrency(invoice.total)}</div>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => setSelectedInvoice(invoice)}
                      className="p-2 rounded-lg hover:bg-white/10 text-white/60 hover:text-white"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    {invoice.status === 'PENDING' && (
                      <button
                        onClick={() => {
                          setSelectedInvoice(invoice);
                          setShowPaymentModal(true);
                        }}
                        className="p-2 rounded-lg hover:bg-green-500/20 text-green-400"
                      >
                        <CreditCard className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              </motion.div>
            );
          })
        )}
      </div>

      {/* Create Invoice Modal */}
      <AnimatePresence>
        {showCreateInvoice && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-black/60" onClick={() => setShowCreateInvoice(false)} />
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-lg p-4 md:p-6 rounded-xl bg-[#2D0A05] border border-white/10 max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg md:text-xl font-semibold text-white">Create New Invoice</h3>
                <button
                  onClick={() => setShowCreateInvoice(false)}
                  className="p-2 rounded-lg hover:bg-white/10 text-white/60"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-white/70 mb-1">Patient *</label>
                  <select
                    value={newInvoice.patientId}
                    onChange={(e) => setNewInvoice({ ...newInvoice, patientId: e.target.value })}
                    className="w-full px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#FF8C42]/50"
                  >
                    <option value="">Select Patient</option>
                    {patients.map((patient) => (
                      <option key={patient.id} value={patient.id}>
                        {patient.firstName} {patient.lastName} ({patient.email})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-3 gap-2 md:gap-4">
                  <div>
                    <label className="block text-xs md:text-sm text-white/70 mb-1">Amount *</label>
                    <Input
                      type="number"
                      value={newInvoice.amount}
                      onChange={(e) => setNewInvoice({ ...newInvoice, amount: e.target.value })}
                      className="bg-white/5 border-white/10 text-white text-sm md:text-base"
                      placeholder="0.00"
                    />
                  </div>
                  <div>
                    <label className="block text-xs md:text-sm text-white/70 mb-1">Tax (%)</label>
                    <Input
                      type="number"
                      value={newInvoice.tax}
                      onChange={(e) => setNewInvoice({ ...newInvoice, tax: e.target.value })}
                      className="bg-white/5 border-white/10 text-white text-sm md:text-base"
                      placeholder="0"
                    />
                  </div>
                  <div>
                    <label className="block text-xs md:text-sm text-white/70 mb-1">Discount</label>
                    <Input
                      type="number"
                      value={newInvoice.discount}
                      onChange={(e) => setNewInvoice({ ...newInvoice, discount: e.target.value })}
                      className="bg-white/5 border-white/10 text-white text-sm md:text-base"
                      placeholder="0.00"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm text-white/70 mb-1">Due Date</label>
                  <Input
                    type="date"
                    value={newInvoice.dueDate}
                    onChange={(e) => setNewInvoice({ ...newInvoice, dueDate: e.target.value })}
                    className="bg-white/5 border-white/10 text-white"
                  />
                </div>

                <div>
                  <label className="block text-sm text-white/70 mb-1">Notes</label>
                  <Textarea
                    value={newInvoice.notes}
                    onChange={(e) => setNewInvoice({ ...newInvoice, notes: e.target.value })}
                    className="bg-white/5 border-white/10 text-white resize-none"
                    rows={2}
                    placeholder="Additional notes..."
                  />
                </div>

                {newInvoice.amount && (
                  <div className="p-3 md:p-4 rounded-lg bg-white/5 border border-white/10">
                    <div className="flex justify-between text-xs md:text-sm text-white/70 mb-1">
                      <span>Subtotal</span>
                      <span>{formatCurrency(parseFloat(newInvoice.amount) || 0)}</span>
                    </div>
                    {parseFloat(newInvoice.tax) > 0 && (
                      <div className="flex justify-between text-xs md:text-sm text-white/70 mb-1">
                        <span>Tax ({newInvoice.tax}%)</span>
                        <span>{formatCurrency((parseFloat(newInvoice.amount) || 0) * parseFloat(newInvoice.tax) / 100)}</span>
                      </div>
                    )}
                    {parseFloat(newInvoice.discount) > 0 && (
                      <div className="flex justify-between text-xs md:text-sm text-green-400 mb-1">
                        <span>Discount</span>
                        <span>-{formatCurrency(parseFloat(newInvoice.discount))}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-base md:text-lg font-bold text-white pt-2 border-t border-white/10 mt-2">
                      <span>Total</span>
                      <span className="text-[#FF8C42]">
                        {formatCurrency(
                          (parseFloat(newInvoice.amount) || 0) +
                          ((parseFloat(newInvoice.amount) || 0) * parseFloat(newInvoice.tax) / 100) -
                          (parseFloat(newInvoice.discount) || 0)
                        )}
                      </span>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex gap-3 mt-6">
                <Button
                  variant="outline"
                  onClick={() => setShowCreateInvoice(false)}
                  className="flex-1 btn-secondary"
                >
                  Cancel
                </Button>
                <Button onClick={handleCreateInvoice} className="flex-1 btn-primary">
                  Create
                </Button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Payment Modal */}
      <AnimatePresence>
        {showPaymentModal && selectedInvoice && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-black/60" onClick={() => setShowPaymentModal(false)} />
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-md p-4 md:p-6 rounded-xl bg-[#2D0A05] border border-white/10"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg md:text-xl font-semibold text-white">Accept Payment</h3>
                <button
                  onClick={() => setShowPaymentModal(false)}
                  className="p-2 rounded-lg hover:bg-white/10 text-white/60"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="p-4 rounded-lg bg-white/5 border border-white/10 mb-6">
                <div className="text-xs md:text-sm text-white/60 mb-1">Invoice {selectedInvoice.invoiceNumber}</div>
                <div className="text-xl md:text-2xl font-bold text-[#FF8C42]">{formatCurrency(selectedInvoice.total)}</div>
                <div className="text-xs md:text-sm text-white/50 mt-1">
                  {selectedInvoice.patient?.firstName} {selectedInvoice.patient?.lastName}
                </div>
              </div>

              <div className="mb-6">
                <label className="block text-sm text-white/70 mb-3">Payment Method</label>
                <div className="grid grid-cols-2 gap-2">
                  {paymentMethods.map((method) => (
                    <button
                      key={method.id}
                      onClick={() => setSelectedPaymentMethod(method.id)}
                      className={`flex items-center gap-2 p-2 md:p-3 rounded-lg border transition-all ${
                        selectedPaymentMethod === method.id
                          ? 'bg-[#C73E1D] border-[#FF8C42] text-white'
                          : 'bg-white/5 border-white/10 text-white/70 hover:bg-white/10'
                      }`}
                    >
                      <method.icon className={`w-4 h-4 ${selectedPaymentMethod === method.id ? 'text-white' : method.color}`} />
                      <span className="text-xs md:text-sm">{method.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => setShowPaymentModal(false)}
                  className="flex-1 btn-secondary"
                  disabled={processingPayment}
                >
                  Cancel
                </Button>
                <Button
                  onClick={handlePayment}
                  className="flex-1 btn-primary"
                  disabled={processingPayment}
                >
                  {processingPayment ? (
                    <span className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Processing...
                    </span>
                  ) : (
                    <>
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Pay
                    </>
                  )}
                </Button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Invoice Detail Modal */}
      <AnimatePresence>
        {selectedInvoice && !showPaymentModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-black/60" onClick={() => setSelectedInvoice(null)} />
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative w-full max-w-lg p-4 md:p-6 rounded-xl bg-[#2D0A05] border border-white/10 max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-start justify-between mb-6">
                <div>
                  <h3 className="text-lg md:text-xl font-semibold text-white">Invoice {selectedInvoice.invoiceNumber}</h3>
                  <p className="text-xs md:text-sm text-white/50">Created {formatDate(selectedInvoice.createdAt)}</p>
                </div>
                <div className={`flex items-center gap-2 px-3 py-1 rounded-full text-xs ${
                  statusConfig[selectedInvoice.status]?.bg || 'bg-white/10'
                } ${statusConfig[selectedInvoice.status]?.color || 'text-white/60'}`}>
                  {selectedInvoice.status}
                </div>
              </div>

              <div className="space-y-3">
                <div className="p-3 md:p-4 rounded-lg bg-white/5">
                  <h4 className="text-xs md:text-sm font-medium text-white/60 mb-2">Patient</h4>
                  <p className="text-white text-sm md:text-base">{selectedInvoice.patient?.firstName} {selectedInvoice.patient?.lastName}</p>
                  <p className="text-xs md:text-sm text-white/50">{selectedInvoice.patient?.email}</p>
                </div>

                <div className="p-3 md:p-4 rounded-lg bg-white/5">
                  <h4 className="text-xs md:text-sm font-medium text-white/60 mb-2">Service</h4>
                  <p className="text-white text-sm md:text-base">{selectedInvoice.appointment?.service?.name || 'N/A'}</p>
                  {selectedInvoice.appointment?.doctor && (
                    <p className="text-xs md:text-sm text-white/50">
                      Dr. {selectedInvoice.appointment.doctor.firstName} {selectedInvoice.appointment.doctor.lastName}
                    </p>
                  )}
                </div>

                <div className="space-y-2 pt-4 border-t border-white/10">
                  <div className="flex justify-between text-white/70 text-sm">
                    <span>Subtotal</span>
                    <span>{formatCurrency(selectedInvoice.amount)}</span>
                  </div>
                  {selectedInvoice.tax > 0 && (
                    <div className="flex justify-between text-white/70 text-sm">
                      <span>Tax</span>
                      <span>{formatCurrency(selectedInvoice.tax)}</span>
                    </div>
                  )}
                  {selectedInvoice.discount > 0 && (
                    <div className="flex justify-between text-green-400 text-sm">
                      <span>Discount</span>
                      <span>-{formatCurrency(selectedInvoice.discount)}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-base md:text-lg font-bold text-white pt-2 border-t border-white/10">
                    <span>Total</span>
                    <span className="text-[#FF8C42]">{formatCurrency(selectedInvoice.total)}</span>
                  </div>
                </div>

                {selectedInvoice.notes && (
                  <div className="p-3 md:p-4 rounded-lg bg-white/5">
                    <h4 className="text-xs md:text-sm font-medium text-white/60 mb-2">Notes</h4>
                    <p className="text-white/70 text-xs md:text-sm">{selectedInvoice.notes}</p>
                  </div>
                )}
              </div>

              <div className="flex flex-col sm:flex-row gap-3 mt-6">
                <Button
                  onClick={() => setSelectedInvoice(null)}
                  className="flex-1 btn-secondary"
                >
                  Close
                </Button>
                {selectedInvoice.status === 'PENDING' && (
                  <Button
                    onClick={() => {
                      setShowPaymentModal(true);
                    }}
                    className="flex-1 btn-primary bg-green-600 hover:bg-green-700"
                  >
                    <CreditCard className="w-4 h-4 mr-2" />
                    Accept Payment
                  </Button>
                )}
                <Button variant="outline" className="btn-secondary">
                  <Printer className="w-4 h-4 mr-2" />
                  Print
                </Button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
