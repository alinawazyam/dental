'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Users, Calendar, DollarSign, Clock, TrendingUp, TrendingDown, ArrowUpRight } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';

interface DashboardStats {
  totalPatients: number;
  todayAppointments: number;
  weekAppointments: number;
  pendingAppointments: number;
  totalRevenue: number;
  monthlyRevenue: number;
  pendingPayments: number;
  newPatientsThisMonth: number;
  totalAppointments: number;
  totalInvoices: number;
  weeklyAppointments: Array<{ day: string; appointments: number }>;
  monthlyRevenueChart: Array<{ month: string; revenue: number }>;
  statusDistribution: {
    PENDING: number;
    CONFIRMED: number;
    COMPLETED: number;
    CANCELLED: number;
    NO_SHOW: number;
  };
  servicePopularity: Record<string, number>;
}

export function AdminDashboard() {
  const [data, setData] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/dashboard')
      .then((res) => res.json())
      .then((responseData) => {
        setData(responseData);
        setLoading(false);
      })
      .catch((err) => {
        console.error('Error fetching dashboard data:', err);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-pulse text-white/60">Loading dashboard...</div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-white/60">Failed to load dashboard data</div>
      </div>
    );
  }

  const statCards = [
    {
      title: "Today's Appointments",
      value: data.todayAppointments || 0,
      icon: Calendar,
      trend: '+12%',
      trendUp: true,
      color: '#FF8C42',
    },
    {
      title: 'Pending Appointments',
      value: data.pendingAppointments || 0,
      icon: Clock,
      trend: '-8%',
      trendUp: false,
      color: '#FFB088',
    },
    {
      title: 'Total Patients',
      value: data.totalPatients || 0,
      icon: Users,
      trend: '+5%',
      trendUp: true,
      color: '#4ADE80',
    },
    {
      title: 'Monthly Revenue',
      value: `$${(data.monthlyRevenue || 0).toLocaleString()}`,
      icon: DollarSign,
      trend: '+15%',
      trendUp: true,
      color: '#22D3EE',
    },
  ];

  return (
    <div className="space-y-4 md:space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
        {statCards.map((stat, index) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="p-4 md:p-6 rounded-xl bg-white/5 border border-white/10"
          >
            <div className="flex items-start justify-between mb-2 md:mb-4">
              <div
                className="w-10 h-10 md:w-12 md:h-12 rounded-xl flex items-center justify-center"
                style={{ backgroundColor: `${stat.color}20` }}
              >
                <stat.icon className="w-5 h-5 md:w-6 md:h-6" style={{ color: stat.color }} />
              </div>
              <div className={`hidden sm:flex items-center gap-1 text-xs md:text-sm ${stat.trendUp ? 'text-green-400' : 'text-red-400'}`}>
                {stat.trendUp ? <TrendingUp className="w-3 h-3 md:w-4 md:h-4" /> : <TrendingDown className="w-3 h-3 md:w-4 md:h-4" />}
                {stat.trend}
              </div>
            </div>
            <div className="text-lg md:text-2xl font-bold text-white mb-0.5 md:mb-1">{stat.value}</div>
            <div className="text-xs md:text-sm text-white/60 line-clamp-1">{stat.title}</div>
          </motion.div>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
        {/* Appointments Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="p-4 md:p-6 rounded-xl bg-white/5 border border-white/10"
        >
          <h3 className="text-base md:text-lg font-semibold text-white mb-4">Weekly Appointments</h3>
          <div className="h-48 md:h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data.weeklyAppointments || []}>
                <defs>
                  <linearGradient id="colorAppointments" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#FF8C42" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#FF8C42" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="day" stroke="#ffffff60" fontSize={10} tick={{ fontSize: 10 }} />
                <YAxis stroke="#ffffff60" fontSize={10} tick={{ fontSize: 10}} width={30} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#2D0A05',
                    border: '1px solid rgba(255,255,255,0.1)',
                    borderRadius: '8px',
                    fontSize: '12px',
                  }}
                  labelStyle={{ color: '#fff', fontSize: '12px' }}
                />
                <Area
                  type="monotone"
                  dataKey="appointments"
                  stroke="#FF8C42"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorAppointments)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Revenue Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="p-4 md:p-6 rounded-xl bg-white/5 border border-white/10"
        >
          <h3 className="text-base md:text-lg font-semibold text-white mb-4">Monthly Revenue</h3>
          <div className="h-48 md:h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.monthlyRevenueChart || []}>
                <XAxis dataKey="month" stroke="#ffffff60" fontSize={10} tick={{ fontSize: 10 }} />
                <YAxis stroke="#ffffff60" fontSize={10} tick={{ fontSize: 10 }} width={30} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#2D0A05',
                    border: '1px solid rgba(255,255,255,0.1)',
                    borderRadius: '8px',
                    fontSize: '12px',
                  }}
                  labelStyle={{ color: '#fff', fontSize: '12px' }}
                  formatter={(value: number) => [`$${value.toLocaleString()}`, 'Revenue']}
                />
                <Bar dataKey="revenue" fill="#FF8C42" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>
      </div>

      {/* Quick Stats */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="p-4 md:p-6 rounded-xl bg-white/5 border border-white/10"
      >
        <h3 className="text-base md:text-lg font-semibold text-white mb-4">Appointment Status Overview</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2 md:gap-4">
          {Object.entries(data.statusDistribution || {}).map(([status, count]) => (
            <div key={status} className="text-center p-3 md:p-4 rounded-lg bg-white/5">
              <div className="text-xl md:text-2xl font-bold text-white mb-0.5 md:mb-1">{count}</div>
              <div className="text-xs md:text-sm text-white/60 capitalize">{status.replace('_', ' ').toLowerCase()}</div>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Additional Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 md:gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="p-4 md:p-6 rounded-xl bg-white/5 border border-white/10"
        >
          <div className="text-xs md:text-sm text-white/60 mb-0.5 md:mb-1">Week Appointments</div>
          <div className="text-xl md:text-2xl font-bold text-white">{data.weekAppointments || 0}</div>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="p-4 md:p-6 rounded-xl bg-white/5 border border-white/10"
        >
          <div className="text-xs md:text-sm text-white/60 mb-0.5 md:mb-1">New Patients This Month</div>
          <div className="text-xl md:text-2xl font-bold text-white">{data.newPatientsThisMonth || 0}</div>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="p-4 md:p-6 rounded-xl bg-white/5 border border-white/10 sm:col-span-2 md:col-span-1"
        >
          <div className="text-xs md:text-sm text-white/60 mb-0.5 md:mb-1">Pending Payments</div>
          <div className="text-xl md:text-2xl font-bold text-white">${(data.pendingPayments || 0).toLocaleString()}</div>
        </motion.div>
      </div>
    </div>
  );
}
