'use client';

import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Plus, Edit, Trash2, User, Phone, Mail, Award, ToggleLeft, ToggleRight, Star, Camera, Upload, Loader2, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';

interface StaffMember {
  id: string;
  name?: string;
  firstName?: string;
  lastName?: string;
  email: string;
  phone?: string | null;
  specialization: string;
  bio?: string | null;
  avatar?: string | null;
  photo?: string | null;
  experience?: number | string | null;
  rating?: number | string | null;
  isActive?: boolean;
  availability?: string;
  createdAt?: string;
}

const specializations = [
  'General Dentist',
  'Implant Specialist',
  'Orthodontist',
  'Cosmetic Dentist',
  'Oral Surgeon',
  'Pediatric Dentist',
  'Endodontist',
  'Periodontist',
];

export function AdminStaff() {
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingStaff, setEditingStaff] = useState<StaffMember | null>(null);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [avatarUrl, setAvatarUrl] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    specialization: 'General Dentist',
    bio: '',
    experience: '',
    avatar: '',
  });

  useEffect(() => {
    fetchStaff();
  }, []);

  const fetchStaff = async () => {
    try {
      const res = await fetch('/api/staff');
      const data = await res.json();
      setStaff(Array.isArray(data) ? data : []);
      setLoading(false);
    } catch {
      console.error('Error fetching staff');
      setLoading(false);
    }
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingPhoto(true);
    try {
      const formDataObj = new FormData();
      formDataObj.append('file', file);
      formDataObj.append('type', 'staff');

      const res = await fetch('/api/upload', {
        method: 'POST',
        body: formDataObj,
      });

      const data = await res.json();

      if (data.success) {
        setAvatarUrl(data.url);
        setFormData(prev => ({ ...prev, avatar: data.url }));
        toast.success('Photo uploaded successfully!');
      } else {
        throw new Error(data.error);
      }
    } catch (error) {
      console.error('Error uploading photo:', error);
      toast.error('Failed to upload photo');
    } finally {
      setUploadingPhoto(false);
    }
  };

  const handleSubmit = async () => {
    if (!formData.firstName || !formData.lastName || !formData.email) {
      toast.error('Please fill in all required fields');
      return;
    }

    try {
      const res = await fetch('/api/staff', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...formData, avatar: avatarUrl }),
      });

      if (!res.ok) throw new Error('Failed to add staff');

      toast.success('Staff member added successfully');
      setShowAddModal(false);
      resetForm();
      fetchStaff();
    } catch {
      toast.error('Failed to add staff');
    }
  };

  const handleUpdate = async () => {
    if (!editingStaff) return;
    
    try {
      const res = await fetch('/api/staff', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: editingStaff.id, ...formData, avatar: avatarUrl || formData.avatar }),
      });

      if (!res.ok) throw new Error('Failed to update staff');

      toast.success('Staff member updated successfully');
      setEditingStaff(null);
      resetForm();
      fetchStaff();
    } catch {
      toast.error('Failed to update staff');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this staff member?')) return;

    try {
      await fetch(`/api/staff?id=${id}`, { method: 'DELETE' });
      toast.success('Staff member deleted successfully');
      fetchStaff();
    } catch {
      toast.error('Failed to delete staff');
    }
  };

  const resetForm = () => {
    setFormData({
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      specialization: 'General Dentist',
      bio: '',
      experience: '',
      avatar: '',
    });
    setAvatarUrl('');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 text-[#FF8C42] animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-lg text-white/70">{staff.length} staff members</h2>
        </div>
        <Button onClick={() => setShowAddModal(true)} className="btn-primary">
          <Plus className="w-4 h-4 mr-2" />
          Add Staff
        </Button>
      </div>

      {/* Staff Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {staff.map((member, index) => (
          <motion.div
            key={member.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className={`p-6 rounded-xl border ${
              member.isActive !== false
                ? 'bg-white/5 border-white/10'
                : 'bg-white/2 border-white/5 opacity-60'
            }`}
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-14 h-14 rounded-full bg-gradient-to-br from-[#FF8C42]/20 to-[#C73E1D]/20 flex items-center justify-center text-white font-medium overflow-hidden border-2 border-[#FF8C42]/30">
                  {member.avatar || member.photo ? (
                    <img src={member.avatar || member.photo} alt={member.name || member.firstName || ''} className="w-full h-full object-cover" />
                  ) : (
                    <span className="text-lg">{(member.name || member.firstName || 'D')[0]}{(member.lastName || '')[0]}</span>
                  )}
                </div>
                <div>
                  <h3 className="font-semibold text-white">Dr. {member.name || `${member.firstName || ''} ${member.lastName || ''}`.trim()}</h3>
                  <span className="text-xs text-[#FF8C42]">{member.specialization}</span>
                </div>
              </div>
            </div>

            <div className="space-y-2 mb-4">
              <div className="flex items-center gap-2 text-sm text-white/60">
                <Mail className="w-4 h-4" />
                <span className="truncate">{member.email}</span>
              </div>
              {member.phone && (
                <div className="flex items-center gap-2 text-sm text-white/60">
                  <Phone className="w-4 h-4" />
                  <span>{member.phone}</span>
                </div>
              )}
              {member.experience && (
                <div className="flex items-center gap-2 text-sm text-white/60">
                  <Award className="w-4 h-4" />
                  <span>{(typeof member.experience === 'number' ? member.experience : parseInt(String(member.experience)) || 5)}+ years experience</span>
                </div>
              )}
            </div>

            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-1">
                <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                <span className="text-sm text-white/70">{(typeof member.rating === 'number' ? member.rating : parseFloat(String(member.rating)) || 4.8).toFixed(1)}</span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-white/10">
              <div className="flex items-center gap-2">
                {member.isActive !== false ? (
                  <ToggleRight className="w-5 h-5 text-green-400" />
                ) : (
                  <ToggleLeft className="w-5 h-5 text-white/40" />
                )}
                <span className={`text-sm ${member.isActive !== false ? 'text-green-400' : 'text-white/40'}`}>
                  {member.isActive !== false ? 'Active' : 'Inactive'}
                </span>
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => {
                    setEditingStaff(member);
                    setAvatarUrl(member.avatar || member.photo || '');
                    setFormData({
                      firstName: member.firstName || (member.name ? member.name.split(' ')[0] : ''),
                      lastName: member.lastName || (member.name ? member.name.split(' ').slice(1).join(' ') : ''),
                      email: member.email || '',
                      phone: member.phone || '',
                      specialization: member.specialization || 'General Dentist',
                      bio: member.bio || '',
                      experience: member.experience?.toString() || '',
                      avatar: member.avatar || member.photo || '',
                    });
                  }}
                  className="p-2 rounded-lg hover:bg-white/10 text-white/60 hover:text-white"
                >
                  <Edit className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(member.id)}
                  className="p-2 rounded-lg hover:bg-red-500/20 text-white/60 hover:text-red-400"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Add/Edit Modal */}
      {(showAddModal || editingStaff) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-black/60"
            onClick={() => {
              setShowAddModal(false);
              setEditingStaff(null);
              resetForm();
            }}
          />
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="relative w-full max-w-lg p-6 rounded-xl bg-[#2D0A05] border border-white/10 max-h-[90vh] overflow-y-auto"
          >
            <h3 className="text-xl font-semibold text-white mb-6">
              {editingStaff ? 'Edit Staff Member' : 'Add New Staff Member'}
            </h3>

            <div className="space-y-4">
              {/* Photo Upload */}
              <div className="flex items-center gap-4 p-4 rounded-xl bg-white/5 border border-white/10">
                <div className="relative">
                  <div className="w-20 h-20 rounded-full bg-gradient-to-br from-[#FF8C42]/20 to-[#C73E1D]/20 flex items-center justify-center text-white font-medium overflow-hidden border-2 border-[#FF8C42]/30">
                    {avatarUrl || formData.avatar ? (
                      <img src={avatarUrl || formData.avatar} alt="Avatar" className="w-full h-full object-cover" />
                    ) : (
                      <User className="w-8 h-8 text-white/50" />
                    )}
                  </div>
                  <button 
                    onClick={() => fileInputRef.current?.click()}
                    disabled={uploadingPhoto}
                    className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-[#C73E1D] border-2 border-[#2D0A05] text-white flex items-center justify-center hover:scale-110 transition-transform disabled:opacity-50"
                  >
                    {uploadingPhoto ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Camera className="w-4 h-4" />
                    )}
                  </button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/png,image/jpeg,image/webp"
                    onChange={handlePhotoUpload}
                    className="hidden"
                  />
                </div>
                <div className="flex-1">
                  <h4 className="font-medium text-white">Staff Photo</h4>
                  <p className="text-sm text-white/50 mb-2">Upload a professional photo (PNG, JPG)</p>
                  <Button 
                    onClick={() => fileInputRef.current?.click()}
                    disabled={uploadingPhoto}
                    size="sm"
                    className="btn-primary"
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    {uploadingPhoto ? 'Uploading...' : 'Upload Photo'}
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-white/70 mb-1">First Name *</label>
                  <Input
                    value={formData.firstName}
                    onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                    className="bg-white/5 border-white/10 text-white"
                  />
                </div>
                <div>
                  <label className="block text-sm text-white/70 mb-1">Last Name *</label>
                  <Input
                    value={formData.lastName}
                    onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                    className="bg-white/5 border-white/10 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm text-white/70 mb-1">Email *</label>
                <Input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="bg-white/5 border-white/10 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-white/70 mb-1">Phone</label>
                  <Input
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="bg-white/5 border-white/10 text-white"
                  />
                </div>
                <div>
                  <label className="block text-sm text-white/70 mb-1">Experience (years)</label>
                  <Input
                    type="number"
                    value={formData.experience}
                    onChange={(e) => setFormData({ ...formData, experience: e.target.value })}
                    className="bg-white/5 border-white/10 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm text-white/70 mb-1">Specialization</label>
                <select
                  value={formData.specialization}
                  onChange={(e) => setFormData({ ...formData, specialization: e.target.value })}
                  className="w-full px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-white focus:outline-none focus:border-[#FF8C42]/50"
                >
                  {specializations.map((spec) => (
                    <option key={spec} value={spec}>
                      {spec}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm text-white/70 mb-1">Bio</label>
                <Textarea
                  value={formData.bio}
                  onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                  className="bg-white/5 border-white/10 text-white resize-none"
                  rows={3}
                />
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <Button
                variant="outline"
                onClick={() => {
                  setShowAddModal(false);
                  setEditingStaff(null);
                  resetForm();
                }}
                className="flex-1 btn-secondary"
              >
                Cancel
              </Button>
              <Button
                onClick={editingStaff ? handleUpdate : handleSubmit}
                className="flex-1 btn-primary"
              >
                {editingStaff ? 'Save Changes' : 'Add Staff'}
              </Button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
