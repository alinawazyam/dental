'use client';

import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, ChevronRight, Clock, CheckCircle, XCircle, AlertCircle, User, Briefcase, Menu } from 'lucide-react';

interface Appointment {
  id: string;
  dateTime: string;
  duration: number;
  status: string;
  notes: string | null;
  patient: { firstName: string; lastName: string; email: string };
  doctor: { firstName: string; lastName: string; specialization: string };
  service: { name: string; price: number };
}

const statusConfig: Record<string, { color: string; icon: typeof CheckCircle }> = {
  PENDING: { color: 'bg-yellow-500/20 text-yellow-400', icon: AlertCircle },
  CONFIRMED: { color: 'bg-blue-500/20 text-blue-400', icon: CheckCircle },
  COMPLETED: { color: 'bg-green-500/20 text-green-400', icon: CheckCircle },
  CANCELLED: { color: 'bg-red-500/20 text-red-400', icon: XCircle },
};

export function AdminAppointments() {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [viewMode, setViewMode] = useState<'list' | 'calendar'>('list');
  const dateRef = useRef(currentDate);

  // Load appointments when date changes
  useEffect(() => {
    const controller = new AbortController();
    
    const loadAppointments = async () => {
      try {
        const date = dateRef.current;
        const dateStr = date.toISOString().split('T')[0];
        const res = await fetch(`/api/appointments?date=${dateStr}`, {
          signal: controller.signal,
        });
        const data = await res.json();
        setAppointments(data);
        setLoading(false);
      } catch {
        if (!controller.signal.aborted) {
          setLoading(false);
        }
      }
    };
    
    loadAppointments();
    
    return () => controller.abort();
  }, [currentDate]);

  const navigateDate = (direction: 'prev' | 'next') => {
    const newDate = new Date(dateRef.current);
    if (direction === 'prev') {
      newDate.setDate(newDate.getDate() - 1);
    } else {
      newDate.setDate(newDate.getDate() + 1);
    }
    dateRef.current = newDate;
    setCurrentDate(newDate);
  };

  const goToToday = () => {
    const today = new Date();
    dateRef.current = today;
    setCurrentDate(today);
  };

  const handleStatusChange = async (appointmentId: string, newStatus: string) => {
    try {
      await fetch('/api/appointments', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: appointmentId, status: newStatus }),
      });
      // Re-fetch appointments
      const dateStr = dateRef.current.toISOString().split('T')[0];
      const res = await fetch(`/api/appointments?date=${dateStr}`);
      const data = await res.json();
      setAppointments(data);
    } catch {
      console.error('Error updating appointment status');
    }
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
    });
  };

  const formatFullDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-pulse text-white/60">Loading appointments...</div>
      </div>
    );
  }

  return (
    <div className="space-y-4 md:space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4">
        {/* Date Navigation */}
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-1 md:gap-2">
            <button
              onClick={() => navigateDate('prev')}
              className="p-2 rounded-lg hover:bg-white/10 text-white/60 hover:text-white"
            >
              <ChevronLeft className="w-4 h-4 md:w-5 md:h-5" />
            </button>
            <div className="text-white font-medium text-sm md:text-base">{formatFullDate(currentDate)}</div>
            <button
              onClick={() => navigateDate('next')}
              className="p-2 rounded-lg hover:bg-white/10 text-white/60 hover:text-white"
            >
              <ChevronRight className="w-4 h-4 md:w-5 md:h-5" />
            </button>
          </div>
          <button
            onClick={goToToday}
            className="px-2 md:px-3 py-1 rounded-lg bg-white/10 text-xs md:text-sm text-white hover:bg-white/20"
          >
            Today
          </button>
        </div>

        {/* View Toggle */}
        <div className="flex gap-2">
          <button
            onClick={() => setViewMode('list')}
            className={`px-3 md:px-4 py-2 rounded-lg text-sm ${
              viewMode === 'list' ? 'bg-[#C73E1D] text-white' : 'bg-white/10 text-white/70'
            }`}
          >
            List
          </button>
          <button
            onClick={() => setViewMode('calendar')}
            className={`px-3 md:px-4 py-2 rounded-lg text-sm ${
              viewMode === 'calendar' ? 'bg-[#C73E1D] text-white' : 'bg-white/10 text-white/70'
            }`}
          >
            Calendar
          </button>
        </div>
      </div>

      {/* Appointments List */}
      {viewMode === 'list' && (
        <div className="space-y-3 md:space-y-4">
          {appointments.length === 0 ? (
            <div className="text-center py-12 text-white/40 rounded-xl bg-white/5 border border-white/10">
              No appointments scheduled for this day
            </div>
          ) : (
            appointments.map((appointment, index) => {
              const StatusIcon = statusConfig[appointment.status]?.icon || Clock;
              const statusColor = statusConfig[appointment.status]?.color || 'bg-white/10 text-white/60';

              return (
                <motion.div
                  key={appointment.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="p-3 md:p-4 rounded-xl bg-white/5 border border-white/10"
                >
                  <div className="flex flex-col gap-4">
                    {/* Time and Status Row */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        {/* Time */}
                        <div className="flex items-center justify-center w-14 md:w-16 p-2 rounded-lg bg-white/5">
                          <span className="text-sm md:text-lg font-bold text-white">{formatTime(appointment.dateTime)}</span>
                        </div>
                        <span className="text-xs text-white/50">{appointment.duration} min</span>
                      </div>
                      
                      {/* Status Badge */}
                      <div className={`flex items-center gap-1 md:gap-2 px-2 md:px-3 py-1 rounded-full text-xs md:text-sm ${statusColor}`}>
                        <StatusIcon className="w-3 h-3 md:w-4 md:h-4" />
                        <span className="hidden sm:inline">{appointment.status}</span>
                      </div>
                    </div>

                    {/* Details */}
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <User className="w-4 h-4 text-[#FF8C42]" />
                        <span className="font-medium text-white text-sm md:text-base">
                          {appointment.patient?.firstName} {appointment.patient?.lastName}
                        </span>
                      </div>
                      <div className="flex flex-wrap items-center gap-2 mb-1 text-xs md:text-sm text-white/60">
                        <Briefcase className="w-4 h-4" />
                        <span>{appointment.service?.name}</span>
                        <span className="text-[#FF8C42]">${appointment.service?.price}</span>
                      </div>
                      <div className="text-xs text-white/50">
                        Dr. {appointment.doctor?.firstName} {appointment.doctor?.lastName} • {appointment.doctor?.specialization}
                      </div>
                    </div>

                    {/* Status Selector */}
                    <div className="flex justify-end">
                      <select
                        value={appointment.status}
                        onChange={(e) => handleStatusChange(appointment.id, e.target.value)}
                        className="px-2 md:px-3 py-1 rounded-lg bg-white/5 border border-white/10 text-xs md:text-sm text-white/70 focus:outline-none focus:border-[#FF8C42]/50"
                      >
                        <option value="PENDING">Pending</option>
                        <option value="CONFIRMED">Confirmed</option>
                        <option value="COMPLETED">Completed</option>
                        <option value="CANCELLED">Cancelled</option>
                      </select>
                    </div>
                  </div>
                </motion.div>
              );
            })
          )}
        </div>
      )}

      {/* Calendar View */}
      {viewMode === 'calendar' && (
        <div className="rounded-xl bg-white/5 border border-white/10 overflow-hidden">
          {/* Time Grid */}
          <div className="divide-y divide-white/5">
            {Array.from({ length: 10 }, (_, i) => {
              const hour = i + 9; // 9 AM to 6 PM
              const hourAppointments = appointments.filter((apt) => {
                const aptHour = new Date(apt.dateTime).getHours();
                return aptHour === hour;
              });

              return (
                <div key={hour} className="flex min-h-[60px] md:min-h-[80px]">
                  <div className="w-14 md:w-20 flex-shrink-0 p-2 md:p-4 border-r border-white/5 text-xs md:text-sm text-white/50 flex items-start justify-center">
                    {hour.toString().padStart(2, '0')}:00
                  </div>
                  <div className="flex-1 p-1 md:p-2 space-y-1">
                    {hourAppointments.map((apt) => (
                      <div
                        key={apt.id}
                        className="px-2 md:px-3 py-1 md:py-2 rounded-lg bg-[#C73E1D]/20 border border-[#FF8C42]/30"
                      >
                        <div className="font-medium text-white text-xs md:text-sm truncate">
                          {apt.patient?.firstName} {apt.patient?.lastName}
                        </div>
                        <div className="text-white/60 text-xs truncate">{apt.service?.name}</div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
