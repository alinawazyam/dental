import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  
  // Correct config for Prisma
  serverExternalPackages: ['@prisma/client'],
};

export default nextConfig;
